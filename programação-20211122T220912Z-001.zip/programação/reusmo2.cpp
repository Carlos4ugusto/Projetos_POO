#include <iostream>

using namespace std;

int pegar_cinco(){
    return 5;
}

int somar_dois(int a, int b){
    return a + b;
}
string verificar_idade(int idade){
    if(idade < 18)
    return "menor de idade";
    if(idade < 65)
    return "adulto";
    return "idoso";//return default
}

int main(){
    /*int y {4};
    int x = pegar_cinco();
    cout << y << endl << x << endl;*/

    /*int x {6}, y {7};
    int z {somar_dois(x, y)};
    cout << z << endl;*/
    
    int x = 0;
    cin >> x;
    cout << verificar_idade(x) << endl;


    return 0;
}