#include <iostream>

using namespace std;

int main(){
cout << "Olá mundo! " << endl;

return 0;
}
